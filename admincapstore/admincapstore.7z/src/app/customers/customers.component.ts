import { Component, OnInit } from '@angular/core';
import { Customer } from '../models/Customer';
import { CustomerService } from './customer.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  customers:Customer[];
  length:number;
  constructor(private customerService:CustomerService) { }

  ngOnInit() {
    this.customerService.getCustomers().subscribe(customers=>{
      this.customers=customers;
      this.length=this.customers.length;
    });
  }

 

deleteCustomer(customerId:number){

    this.customerService.deleteCustomer(customerId).subscribe(customers => this.customers=customers);
}



}
