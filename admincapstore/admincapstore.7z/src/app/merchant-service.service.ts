import { Injectable } from '@angular/core';
import { Merchant } from './merchant';
import {HttpClient,HttpHeaders} from '@angular/common/http'
import {Observable} from 'rxjs'
import { of } from 'rxjs'

const headers= new HttpHeaders({ 'Content-Type':'application/json'});


@Injectable({
  providedIn: 'root'
})
export class MerchantService {
  private custUrl='http://localhost:8081/day3-Spring5Rest/api/merchants';
  merchants:Merchant[];

  constructor(private http: HttpClient) { }

  getMerchants(): Observable<Merchant[]>
 {

  console.log(('Merchants here!!'+this.http.get<Merchant[]>(this.custUrl+'/all')));
  return this.http.get<Merchant[]>(this.custUrl);
  
 }


 deleteMerchant(merchantId:number) :Observable<Merchant[]>
 {
  this.custUrl=this.custUrl+'/'+merchantId;
  return this.http.delete<Merchant[]>(this.custUrl);
 }

 verifyMerchant(merchant:Merchant):Observable<Merchant[]>
 {
   console.log(merchant);
   return this.http.put<Merchant[]>('http://localhost:8081/day3-Spring5Rest/api/insertcustomers',merchant,{});
 }
 

  
}
